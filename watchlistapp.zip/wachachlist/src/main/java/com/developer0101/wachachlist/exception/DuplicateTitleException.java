package com.developer0101.wachachlist.exception;

public class DuplicateTitleException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
