package com.developer0101.wachachlist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WachachlistApplication {

	public static void main(String[] args) {
		SpringApplication.run(WachachlistApplication.class, args);
	}

}
