package com.developer0101.wachachlist.actuator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

import com.developer0101.wachachlist.service.MovieRatingService;
@Component
public class HealthCheck implements HealthIndicator {
    @Autowired
	private MovieRatingService movieRatingService;

	public HealthCheck(MovieRatingService movieRatingService) {
		super();
		this.movieRatingService = movieRatingService;
	}
	@Override
	public Health health() {
		if(movieRatingService.getMovieRating("UP")==null) {
			return Health.down().withDetail("Cause", "OMDB Api is not available").build();
		}
		return Health.up().build();
	}
      
}
