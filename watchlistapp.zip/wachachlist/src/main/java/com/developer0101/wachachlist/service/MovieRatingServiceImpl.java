package com.developer0101.wachachlist.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.node.ObjectNode;
@ConditionalOnProperty(name = "app.environment", havingValue = "pro")
@Service
public class MovieRatingServiceImpl implements MovieRatingService {
	
    private static final String apiUrl = "https://www.omdbapi.com/?apikey=abd2a612&t=";
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
      
      @Override
      public String getMovieRating(String title) {
		
		try {
			RestTemplate template = new RestTemplate();
			
			logger.info("OMDb API called with URL: {}", apiUrl + title);
			
			ResponseEntity<ObjectNode> response = 
					template.getForEntity(apiUrl + title, ObjectNode.class);
			
			ObjectNode jsonObject = response.getBody();
			logger.debug("OMDb API response: {}", jsonObject);
			
			return jsonObject.path("imdbRating").asText();
		} catch (Exception e) {
			System.out.println("Something went wront while calling OMDb API" + e.getMessage());
			logger.warn("Something went wront while calling OMDb API" + e.getMessage());
			return null;
		}
	}

}
