package com.developer0101.wachachlist;



import static org.junit.Assert.assertTrue;

import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.mockito.ArgumentMatchers.any;

import com.developer0101.wachachlist.domain.WatchlistItem;
import com.developer0101.wachachlist.repository.WatchlistRepository;
import com.developer0101.wachachlist.service.MovieRatingService;
import com.developer0101.wachachlist.service.WatchlistService;


@RunWith(MockitoJUnitRunner.class)
public class WatchlistServiceTest {
	
	@InjectMocks
	private WatchlistService watchlistService;
	
	@Mock
	private WatchlistRepository watchlistRepositoryMock;
	
	@Mock
	private MovieRatingService movieRatingServiceMock;
	
	@Test
	public void testGetWatchlistItemsReturnsAllItemsFromRepository() {
		
		//Arrange
		WatchlistItem item1 = new WatchlistItem("Star Wars", "7.7", "M" , "");
		WatchlistItem item2 = new WatchlistItem("Star Treck", "8.8", "M" , "");
		List<WatchlistItem> mockItems = Arrays.asList(item1, item2);
		
		when(watchlistRepositoryMock.getList()).thenReturn(mockItems);
		
		//Act
		List<WatchlistItem> result = watchlistService.getWatchlistItems();
		
		//Assert
		assertTrue(result.size() == 2);
		assertTrue(result.get(0).getTitle().equals("Star Wars"));
		assertTrue(result.get(1).getTitle().equals("Star Treck"));
	}
	@Test
	public void testGetwatchlistItemsRatingFormOmdbSericeOverrideTheValueInItems() {
		//arrange
		WatchlistItem item1 = new WatchlistItem("Star Wars", "7.7", "M" , "");
		List<WatchlistItem> mockItems = Arrays.asList(item1);
		when(watchlistRepositoryMock.getList()).thenReturn(mockItems);
		when(movieRatingServiceMock.getMovieRating(any(String.class))).thenReturn("10");
		//act
		List<WatchlistItem> result = watchlistService.getWatchlistItems();
		//assert
		assertTrue(result.get(0).getRating().equals("10"));
	}
	@Test
	public void testGetWachlistItemsSize() {
		//arrange
		WatchlistItem item1 = new WatchlistItem("Star Wars", "7.7", "M" , "");
		WatchlistItem item2 = new WatchlistItem("Star Treck", "8.8", "M" , "");
		List<WatchlistItem> mockItems = Arrays.asList(item1, item2);
		when(watchlistRepositoryMock.getList()).thenReturn(mockItems);
		//act
		List<WatchlistItem> result = watchlistService.getWatchlistItems();
		//assets
		assertTrue(result.size() == 2);
	}
}